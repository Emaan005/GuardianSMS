import urllib.request
import zipfile
import os
import pandas as pd

# Download SMS Spam Collection dataset
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00228/smsspamcollection.zip"
print("Downloading dataset...")
urllib.request.urlretrieve(url, "smsspamcollection.zip")

# Extract
print("Extracting...")
with zipfile.ZipFile("smsspamcollection.zip", 'r') as zip_ref:
    zip_ref.extractall("dataset/")

# Load and verify
df = pd.read_csv("dataset/SMSSpamCollection", sep='\t', header=None, names=['label', 'message'])
print(f"Dataset loaded: {len(df)} messages")
print(f"Spam: {len(df[df['label']=='spam'])} | Ham: {len(df[df['label']=='ham'])}")
print("\nSample:")
print(df.head())

# Save as CSV for easy use
df.to_csv("dataset/sms_dataset.csv", index=False)
print("\n✅ Dataset saved to dataset/sms_dataset.csv")