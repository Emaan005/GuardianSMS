from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import re
import nltk
from nltk.corpus import stopwords
import os

app = Flask(__name__)
CORS(app)

# Download NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except:
    nltk.download('stopwords', quiet=True)

print("="*60)
print("🛡️ GuardianSMS Backend Server")
print("="*60)

class SMSClassifier:
    def __init__(self):
        self.model = None
        self.stop_words = set(stopwords.words('english'))
        self.load_model()
    
    def load_model(self):
        model_path = 'models/naive_bayes_model.pkl'
        if os.path.exists(model_path):
            self.model = joblib.load(model_path)
            print(f"✅ Model loaded from {model_path}")
            return True
        else:
            print(f"❌ Model not found at {model_path}")
            print("   Please run model_trainer.py first!")
            return False
    
    def clean_text(self, text):
        text = text.lower()
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        text = ' '.join([word for word in text.split() if word not in self.stop_words])
        return text
    
    def predict(self, message):
        if self.model is None:
            return {
                'is_spam': False,
                'label': 'ham',
                'confidence': 0,
                'threat_score': 0,
                'error': 'Model not loaded'
            }
        
        cleaned = self.clean_text(message)
        prediction = self.model.predict([cleaned])[0]
        probabilities = self.model.predict_proba([cleaned])[0]
        
        # Get index for spam class
        spam_idx = list(self.model.classes_).index('spam')
        ham_idx = list(self.model.classes_).index('ham')
        
        # threat_score = probability of being SPAM (this is what should be high for spam)
        spam_probability = probabilities[spam_idx]
        ham_probability = probabilities[ham_idx]
        
        # FIXED: threat_score is the probability of being SPAM
        # For safe messages, this should be LOW (near 0)
        # For spam messages, this should be HIGH (near 100)
        threat_score = spam_probability * 100
        
        return {
            'is_spam': prediction == 'spam',
            'label': prediction,
            'confidence': round(spam_probability * 100 if prediction == 'spam' else ham_probability * 100, 2),
            'threat_score': round(threat_score, 2),  # This is now correctly the SPAM probability
            'spam_probability': round(spam_probability * 100, 2),
            'ham_probability': round(ham_probability * 100, 2),
            'message_preview': message[:100]
        }

# Initialize classifier
classifier = SMSClassifier()

@app.route('/', methods=['GET'])
def home():
    return jsonify({
        'name': 'GuardianSMS API',
        'version': '1.0.0',
        'status': 'running',
        'model_loaded': classifier.model is not None
    })

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        message = data.get('message', '')
        
        if not message:
            return jsonify({'error': 'No message provided'}), 400
        
        result = classifier.predict(message)
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/bulk-predict', methods=['POST'])
def bulk_predict():
    try:
        data = request.get_json()
        messages = data.get('messages', [])
        
        if not messages:
            return jsonify({'error': 'No messages provided'}), 400
        
        results = []
        for msg in messages:
            if msg.strip():
                result = classifier.predict(msg)
                results.append(result)
        
        spam_count = sum(1 for r in results if r['is_spam'])
        
        return jsonify({
            'total': len(results),
            'spam_count': spam_count,
            'ham_count': len(results) - spam_count,
            'results': results
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'healthy',
        'model_loaded': classifier.model is not None
    })

if __name__ == '__main__':
    print("\n🌐 Starting Flask server...")
    print("📍 API Endpoints:")
    print("   GET  /           - API Info")
    print("   GET  /health     - Health check")
    print("   POST /predict    - Single message prediction")
    print("   POST /bulk-predict - Bulk prediction")
    print("\n🚀 Server running on http://localhost:5000")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)