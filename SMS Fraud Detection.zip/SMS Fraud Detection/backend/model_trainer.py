import pandas as pd
import re
import nltk
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
from sklearn.pipeline import Pipeline

# Download NLTK data
nltk.download('stopwords', quiet=True)
from nltk.corpus import stopwords

print("="*60)
print("🚀 GuardianSMS - Naive Bayes Model Training")
print("="*60)

class SpamDetector:
    def __init__(self):
        self.stop_words = set(stopwords.words('english'))
        self.pipeline = Pipeline([
            ('tfidf', TfidfVectorizer(max_features=5000, ngram_range=(1, 2))),
            ('nb', MultinomialNB(alpha=0.5))
        ])
    
    def clean_text(self, text):
        """Clean and preprocess SMS text"""
        text = text.lower()
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        text = ' '.join([word for word in text.split() if word not in self.stop_words])
        return text
    
    def train(self, X_train, y_train):
        print("\n📚 Training Naive Bayes model...")
        self.pipeline.fit(X_train, y_train)
        print("✅ Training complete!")
        return self
    
    def predict(self, X):
        return self.pipeline.predict(X)
    
    def predict_proba(self, X):
        return self.pipeline.predict_proba(X)
    
    def evaluate(self, X_test, y_test):
        y_pred = self.predict(X_test)
        
        print("\n" + "="*60)
        print("📊 MODEL EVALUATION RESULTS")
        print("="*60)
        print(f"✅ Accuracy:  {accuracy_score(y_test, y_pred):.4f} x 100 = {accuracy_score(y_test, y_pred)*100:.2f}%")
        print(f"🎯 Precision: {precision_score(y_test, y_pred, pos_label='spam'):.4f}")
        print(f"📈 Recall:    {recall_score(y_test, y_pred, pos_label='spam'):.4f}")
        print(f"🏆 F1-Score:  {f1_score(y_test, y_pred, pos_label='spam'):.4f}")
        print("\n📋 Detailed Classification Report:")
        print(classification_report(y_test, y_pred))
        
        return {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred, pos_label='spam'),
            'recall': recall_score(y_test, y_pred, pos_label='spam'),
            'f1': f1_score(y_test, y_pred, pos_label='spam')
        }
    
    def save_model(self, path='models/naive_bayes_model.pkl'):
        os.makedirs('models', exist_ok=True)
        joblib.dump(self.pipeline, path)
        print(f"\n💾 Model saved to {path}")
        return path

def main():
    # Load dataset - FIXED PATH
    print("\n📂 Loading dataset...")
    
    # Check if file exists in backend/dataset/
    csv_path = 'dataset/sms_dataset.csv'
    if not os.path.exists(csv_path):
        print(f"❌ Error: Could not find {csv_path}")
        print("   Current directory:", os.getcwd())
        print("   Please make sure the dataset is in the correct location")
        return
    
    df = pd.read_csv(csv_path)
    print(f"   Loaded {len(df)} messages")
    print(f"   📧 Ham: {len(df[df['label']=='ham'])} | 🚫 Spam: {len(df[df['label']=='spam'])}")
    
    # Create detector instance
    detector = SpamDetector()
    
    # Preprocess
    print("\n🔧 Preprocessing text...")
    df['cleaned_message'] = df['message'].apply(detector.clean_text)
    
    # Prepare features and labels
    X = df['cleaned_message'].values
    y = df['label'].values
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"\n📊 Data Split:")
    print(f"   Training: {len(X_train)} messages")
    print(f"   Testing:  {len(X_test)} messages")
    
    # Train model
    detector.train(X_train, y_train)
    
    # Evaluate
    metrics = detector.evaluate(X_test, y_test)
    
    # Save model
    model_path = detector.save_model()
    
    # Save additional files
    joblib.dump(detector.stop_words, 'models/stopwords.pkl')
    
    print("\n" + "="*60)
    print("🎉 MODEL TRAINING COMPLETED SUCCESSFULLY!")
    print("="*60)
    print(f"\n📁 Files saved in 'models/' folder:")
    print("   - naive_bayes_model.pkl (main model)")
    print("   - stopwords.pkl (text preprocessing)")
    
    return detector, metrics

if __name__ == "__main__":
    main()